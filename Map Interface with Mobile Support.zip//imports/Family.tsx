
import IconEducation from "./IconEducation";

export default function Family() {
  return (
    <div className="relative size-full" data-name="family">
      <IconEducation />
    </div>
  );
}
